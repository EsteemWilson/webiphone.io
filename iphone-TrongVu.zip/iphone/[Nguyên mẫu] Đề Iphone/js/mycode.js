function CustomerInfo() {
    var message = "Thank you for trusting and using our products in the past time!!!";

    alert("This page says\n\n" + message);
}
